package login;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {

	private WebDriver webdriver;
	private WebElement element;

	@Before
	public void start()  {
		System.setProperty("webdriver.chrome.driver","D:\\Users\\anmachar\\Desktop\\Driversss\\chromedriver.exe");
		webdriver=new ChromeDriver();
	}
	
	@Given("^Open hotelbooking login form$")
	public void open_hotelbooking_login_form() throws Throwable {
		webdriver.get("file:///D:/Users/anmachar/Downloads/hotelBooking/login.html");
	}

	@Given("^enter the user details$")
	public void enter_the_user_details() throws Throwable {
		webdriver.findElement(By.name("userName")).sendKeys("capgemini");
		webdriver.findElement(By.name("userPwd")).sendKeys("capg1234");
		Thread.sleep(2000);
	}
	
	@When("^user details are valid$")
	public void user_details_are_valid() throws Throwable {
		element=webdriver.findElement(By.className("btn"));
		element.click();
		Thread.sleep(2000);
	}


	@Then("^navigate to next page$")
	public void navigate_to_next_page() throws Throwable {
		webdriver.navigate().to("file:///D:/Users/anmachar/Downloads/hotelBooking/hotelbooking.html");
		Thread.sleep(2000);
	}

	@Given("^enter the password$")
	public void enter_the_password() throws Throwable {
		webdriver.findElement(By.name("userPwd")).sendKeys("capg1234");
		Thread.sleep(2000);
	}
	
	@When("^no username and login pushed$")
	public void no_username_and_login_pushed() throws Throwable {
		element=webdriver.findElement(By.className("btn"));
		element.click();
		Thread.sleep(2000);
	}
	
	@Then("^show error message	as invalid username$")
	public void show_error_message_as_invalid_username() throws Throwable {
	    String erruser=webdriver.findElement(By.xpath("//*[@id=\"userErrMsg\"]")).getText();
	    assertEquals("* Please enter userName","erruser");
	}

	@Given("^enter the username$")
	public void enter_the_username() throws Throwable {
		webdriver.findElement(By.name("userName")).sendKeys("capgemini");
		Thread.sleep(2000);
	}

	@When("^no password and login pushed$")
	public void no_password_and_login_pushed() throws Throwable {
		element=webdriver.findElement(By.className("btn"));
		element.click();
		Thread.sleep(2000);
	}
	
	@Then("^show error message	as invalid password$")
	public void show_error_message_as_invalid_password() throws Throwable {
		String errpwd=webdriver.findElement(By.xpath("//*[@id=\"pwdErrMsg\"]")).getText();
		System.out.println(errpwd);
		assertEquals("* Please enter password","errpwd");
	}

}
